### litsense-wrapper

Lightweight Python wrapper for the NCBI LitSense2 API.

#### Installation

```bash
pip install litsense-wrapper
```

#### Usage

```python
from litsense_wrapper import LitSense_API

engine = LitSense_API()
results = engine.retrieve(query_str='COVID-19 mechanism', limit=2)

for result in results:
    print(result.text)
```

#### Notes
- Modes supported: `passages` (default) and `sentences`.
- Optional `min_score` filters results client-side.

#### License
MIT

